<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://dofit.me
 * @since      1.0.0
 *
 * @package    App_Custom_Api
 * @subpackage App_Custom_Api/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
